package brun.christian.model.domain;

public class Esfera extends FiguraGeometrica3D {

	private float radio;
	private final float PI = 3.141592f;
	
	
	public Esfera(float radio)
	{
		this.radio = radio;
	}
	
	public float getRadio()
	{
		return radio;
	}
	
	public void setRadio(float radio)
	{
		this.radio = radio;
	}
	
	
	@Override
	public float calcularAreaFigura() {

		return 4 * PI * radio * radio;
	}

}
