package christian.brun.domain;

public enum EstadoLibro {

	DISPONIBLE, PRESTADO;
}
