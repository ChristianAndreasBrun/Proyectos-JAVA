package brun.christian.lambdas;

@FunctionalInterface
public interface IOperacionesMatematicasBasicas {

	double operacion(double valor1, double valor2);
}
